#!/bin/bash

results_dir=$1
c_file=$2
shift 2

base=`pwd`
J=1

for subj in "$@" ; do
    [ -d $subj ] || continue
    cd ${subj}/raw
    
    echo "matlabbatch{$J}.spm.stats.fmri_spec.timing.units = 'secs';"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.timing.RT = 2;"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.timing.fmri_t = 16;"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.timing.fmri_t0 = 1;"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.dir = {'${base}/${subj}/${results_dir}/'}"

    S=1
    
    for session in `ls sw*.nii`; do
	echo "matlabbatch{$J}.spm.stats.fmri_spec.sess($S).scans = {"

	N=`echo $session | cut -f1 -d. | tail -c 4`
	
	for ((image=1;image<N;++image)); do 
	    echo "'${base}/${subj}/raw/${session},${image}'"
	done

	echo "};"
	echo "matlabbatch{$J}.spm.stats.fmri_spec.sess($S).cond = struct('name', {}, 'onset', {}, 'duration', {}, 'tmod', {}, 'pmod', {});"
	echo "matlabbatch{$J}.spm.stats.fmri_spec.sess($S).multi = {'${base}/${subj}/behav/session${S}.mat'};"
	echo "matlabbatch{$J}.spm.stats.fmri_spec.sess($S).regress = struct('name', {}, 'val', {});"
	echo "matlabbatch{$J}.spm.stats.fmri_spec.sess($S).multi_reg = {''};"
	echo "matlabbatch{$J}.spm.stats.fmri_spec.sess($S).hpf = 128;"
	
	S=$((S+1))
    done
    echo "matlabbatch{$J}.spm.stats.fmri_spec.fact = struct('name', {}, 'levels', {});"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.bases.hrf.derivs = [0 0];"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.volt = 1;"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.global = 'None';"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.mask = {''};"
    echo "matlabbatch{$J}.spm.stats.fmri_spec.cvi = 'AR(1)';"
    
    cd ../../
    J=$((J+1))

    echo -e "\n % Estimate\n"
    
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1) = cfg_dep;"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).tname = 'Select SPM.mat';"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).tgt_spec{1}(1).name = 'filter';"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).tgt_spec{1}(1).value = 'mat';"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).tgt_spec{1}(2).name = 'strtype';"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).tgt_spec{1}(2).value = 'e';"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).sname = 'fMRI model specification: SPM.mat File';"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).src_exbranch = substruct('.','val', '{}',{$((J-1))}, '.','val', '{}',{1}, '.','val', '{}',{1});"
    echo "matlabbatch{$J}.spm.stats.fmri_est.spmmat(1).src_output = substruct('.','spmmat');"
    echo "matlabbatch{$J}.spm.stats.fmri_est.method.Classical = 1;"
    
    J=$((J+1))
    
    echo -e "\n% Contrast manager"
    
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1) = cfg_dep;"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).tname = 'Select SPM.mat';"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).tgt_spec{1}(1).name = 'filter';"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).tgt_spec{1}(1).value = 'mat';"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).tgt_spec{1}(2).name = 'strtype';"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).tgt_spec{1}(2).value = 'e';"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).sname = 'Model estimation: SPM.mat File';"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).src_exbranch = substruct('.','val', '{}',{$((J-1))}, '.','val', '{}',{1}, '.','val', '{}',{1});"
    echo "matlabbatch{$J}.spm.stats.con.spmmat(1).src_output = substruct('.','spmmat');"
    
    C=1
    while read line; do
	cname=`echo $line | cut -f1 -d:`
	cvector=`echo $line | cut -f2 -d:`
	echo "matlabbatch{$J}.spm.stats.con.consess{$C}.tcon.name = '${cname}';"
	echo "matlabbatch{$J}.spm.stats.con.consess{$C}.tcon.convec = [${cvector}];"
	echo "matlabbatch{$J}.spm.stats.con.consess{$C}.tcon.sessrep = 'replsc';"
	C=$((C+1))
	
    done < ${c_file}
    echo "matlabbatch{$J}.spm.stats.con.delete = 1;"
    
    J=$((J+1))
    

done

