#!/bin/bash

## ---------------------------------------------------------------- ##
## EXTRACT-DCM-DATA.SH
## ---------------------------------------------------------------- ##
## Extract DCMs for the Autism task
## ---------------------------------------------------------------- ##
## History 
## ---------------------------------------------------------------- ##
## 2012-02-07 : Generalized the code. Now takes the model as an 
##            : argument.
##
## 2012-02-02 : File created
## ---------------------------------------------------------------- ##

NL="
"   # new line

HELP_MSG="extract-voi-data
 --------------------------------------
 This program extracts the various VOI
 information for a specific VOI. 
  
 Usage
 --------------------------------------
 $ extract-voi-data.sh <voi> <sub1> 
                    <sub2> ... <subN>
 
 where:
   <voi>   is the VOI name 
          (without the '_1.mat')
   <subX>   is the [list of] of subject
          folders.

 Notes
 --------------------------------------
 * The script must be run from the root
   folder, where all the subjects 
   folders are located
 * Each subject folder must have a 'DCM'
   directory where the VOI is located
 * At least two arguments need to be 
   provided (VOI and at least one 
   subject)
" 

if [ $# -lt 2 ]; then
    echo "$HELP_MSG"
    exit
fi

VOI=$1
shift

MFILE=`pwd`/extract_${VOI}_data_`date +%Y_%m_%d_%H%M`.m
BASE_DIR="`pwd`"
DCM_DIR="DCM"


echo "% Extracting VOI data for $@" > $MFILE
#echo "resA_file=fopen('${BASE_DIR}/${subj}/${MODEL}_data_A.txt', 'a');" >> $MFILE
#echo "resB_file=fopen('${BASE_DIR}/${subj}/${MODEL}_data_B.txt', 'a');" >> $MFILE
#echo "resC_file=fopen('${BASE_DIR}/${subj}/${MODEL}_data_C.txt', 'a');" >> $MFILE
#echo "resD_file=fopen('${BASE_DIR}/${subj}/${MODEL}_data_D.txt', 'a');" >> $MFILE

for subj in $@; do
    echo "disp('Extracting VOI ${VOI} data for ${subj}');" >> $MFILE
    echo "subj_file = fopen('${BASE_DIR}/${subj}/DCM/${subj}_${VOI}_xyz.txt', 'w');" >> $MFILE
    echo "res_file  = fopen('${BASE_DIR}/${VOI}_xyz.txt', 'a');" >> $MFILE
    echo "load(fullfile('${BASE_DIR}', '${subj}', '$DCM_DIR', 'VOI_${VOI}_1.mat'), 'xY');" >> $MFILE

    echo "fprintf(subj_file, '%s\t', xY.name);" >> $MFILE
    echo "fprintf(subj_file, '%f\t', xY.xyz');" >> $MFILE
    echo "fprintf(subj_file, '\n');" >> $MFILE

    echo "fprintf(res_file, '%s\t', '${subj}');" >> $MFILE
    echo "fprintf(res_file, '%s\t', xY.name);" >> $MFILE
    echo "fprintf(res_file, '%f\t', xY.xyz');" >> $MFILE
    echo "fprintf(res_file, '\n');" >> $MFILE

    echo "${NL}%------------------------------------${NL}" >> $MFILE
done